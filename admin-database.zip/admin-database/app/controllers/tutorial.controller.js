const db = require("../models");
const Users = db.users;
const Op = db.Sequelize.Op;

// Create and Save a new Tutorial
exports.create = (req, res) => {
    // Validate request
    if (!req.body.username) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
      return;
    }
  
    // Create a Tutorial
    const users = {
      fullName: req.body.fullName,
      email: req.body.email,
      username: req.body.username,
      password: req.body.password
    };
  
    // Save Tutorial in the database
    Users.create(users)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Tutorial."
        });
      });
  };
  
  // Retrieve all Tutorials from the database.
      exports.findAll = (req, res) => {
          const username = req.query.username;
          var condition = username ? { username: { [Op.like]: `%${username}%` } } : null;
        
          Users.findAll({ where: condition })
            .then(data => {
              res.send(data);
            })
            .catch(err => {
              res.status(500).send({
                message:
                  err.message || "Some error occurred while retrieving tutorials."
              });
            });
      };
  
  // Find a single Tutorial with an id
  exports.findOne = (req, res) => {
    const username = req.params.username;
  
    Users.findByPk(username)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message: "Error retrieving Tutorial with Username=" + username
        });
      });
  };
  
  // Update a Tutorial by the id in the request
  exports.update = (req, res) => {
      const username = req.params.username;
  
    Users.update(req.body, {
      where: { username: username }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "List was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update list with Event Name=${username}. Maybe list was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating List with Event Name=" + username
        });
      });
  };
  
  // Delete a Tutorial with the specified id in the request
  exports.delete = (req, res) => {
      const username = req.params.username;
  
    Users.destroy({
      where: { username: username }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "List was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete List with Username=${username}. Maybe List was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete List with Username=" + username
        });
      });
  };
  
  // Delete all Tutorials from the database.
  exports.deleteAll = (req, res) => {
      Users.destroy({
          where: {},
          truncate: false
        })
          .then(nums => {
            res.send({ message: `${nums} Tutorials were deleted successfully!` });
          })
          .catch(err => {
            res.status(500).send({
              message:
                err.message || "Some error occurred while removing all tutorials."
            });
          });
  };
  